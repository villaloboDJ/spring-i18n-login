package org.example.springsecurity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Locale;

@Controller
public class CustomerController {

    @Autowired
    private MessageSource messageSource;

    @GetMapping("/login")
    public String loginPage(Locale locale, Model model) {
        model.addAttribute("loginTitle", messageSource.getMessage("login.title", null, locale));
        model.addAttribute("loginUsername", messageSource.getMessage("login.username", null, locale));
        model.addAttribute("loginPassword", messageSource.getMessage("login.password", null, locale));
        model.addAttribute("loginButton", messageSource.getMessage("login.button", null, locale));
        return "login";
    }

    @GetMapping("/public")
    @ResponseBody
    public String publicEndpoint(Locale locale) {
        return messageSource.getMessage("public.endpoint", null, locale);
    }

    @GetMapping("/admin")
    @ResponseBody
    public String adminEndpoint(Locale locale) {
        return messageSource.getMessage("admin.welcome", null, locale);
    }

    @GetMapping("/user")
    @ResponseBody
    public String userEndpoint(Locale locale) {
        return messageSource.getMessage("user.welcome", null, locale);
    }

    @GetMapping("/")
    @ResponseBody
    public String home(Locale locale) {
        return messageSource.getMessage("home.text", null, locale);
    }
}
